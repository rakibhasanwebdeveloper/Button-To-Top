<?php
/**
 * Plugin Name:       Button To Top 
 * Plugin URI:        https://wordpress.org/plugins/button-to-top/
 * Description:       Top to Bottom Bottom to top is a WordPress plugin to generate up/down buttons that allow the user to scroll the page to the top or bottom with a smooth scrolling effect.
 * Version:           1.0.0
 * Requires at least: 5.2
 * Requires PHP:      7.2
 * Author:            Rakib Hasan
 * Author URI:        https://freelancerrakib.site/
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       ttbbtt
 */

// Enqueue CSS
function ttbbtt_enqueue_style() {
    wp_enqueue_style('ttbbtt', plugin_dir_url(__FILE__) . 'css/ttbbtt-style.css');
}
add_action('wp_enqueue_scripts', 'ttbbtt_enqueue_style');

// Enqueue JavaScript
function ttbbtt_enqueue_scripts() {
    wp_enqueue_script('jquery');
    wp_enqueue_script('ttbbtt-plugin-scripts', plugin_dir_url(__FILE__) . 'js/ttbbtt-plugin.js', array('jquery'), '1.0.0', true);
}
add_action('wp_enqueue_scripts', 'ttbbtt_enqueue_scripts');

// Scroll Up Plugin Activation
function ttbbtt_scroll_scripts() {
    ?>
    <script>
        jQuery(document).ready(function($) {
            var $button = $.backToTop({
                // background color
                backgroundColor: '#5D5D5D',

                // text color
                color: '#FFFFFF',

                // container element
                container: $('body'), 

                // 'nonn', 'spin', 'fade', 'zoom', or 'spin-inverse'
                effect: 'spin',

                // enable the back to top button
                enabled: true, 

                // width/height of the back to top button
                height: 70,  
                width: 70,

                // icon
                icon: 'fas fa-chevron-up',

                // margins 
                marginX: 20,
                marginY: 20,  

                // bottom/top left/right
                position: 'bottom right',           

                // trigger position
                pxToTrigger: 600,

                // or 'fawesome'
                theme: 'default',

                // z-index
                zIndex: 999
            });
        });
    </script>
    <?php
}
add_action('wp_footer', 'ttbbtt_scroll_scripts');
?>